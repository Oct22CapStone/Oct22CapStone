package com.mtumer.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mtumer.entity.Message;
import com.mtumer.repo.MessageRepo;

@Service
@Transactional
public class MessagesService {
	
	private MessageRepo messageRepo;
	
	@Autowired
	public MessagesService(MessageRepo messageRepo) {
		this.messageRepo = messageRepo;
	}
	
	public void postMessage(Message messageRequest, String userEmail) {
		Message message = new Message(messageRequest.getTitle(), messageRequest.getQuestion());
		message.setUserEmail(userEmail);
		messageRepo.save(message);
	}
	
	
	
	

}
