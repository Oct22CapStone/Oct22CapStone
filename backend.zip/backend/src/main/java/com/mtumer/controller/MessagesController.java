package com.mtumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mtumer.entity.Message;
import com.mtumer.services.ExtractJWT;
import com.mtumer.services.MessagesService;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/messages") // /api/messages
public class MessagesController {
	
	@Autowired
	private MessagesService messagesService;
	
	
	public MessagesController(MessagesService messagesService) {
		this.messagesService = messagesService;
	}
	
	@PostMapping("/add/message") // /secure/add/message
	//public void postMessage(@RequestHeader(value="Authorization") String token, @RequestBody Message messageRequest) {
	public void postMessage(@RequestBody Message messageRequest) {
		//Get email from token
		//String userEmail =  ExtractJWT.payloadJWTExtraction(token, "\"sub\"");
		//messagesService.postMessage(messageRequest, userEmail);
		String userEmail = "hello@email.com";
		messagesService.postMessage(messageRequest, userEmail);

	}

}






















