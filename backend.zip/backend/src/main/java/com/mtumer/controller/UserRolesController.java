/*package com.mtumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mtumer.services.UserRoleService;



@RestController
@RequestMapping("/user_role")
public class UserRolesController {
	
	@Autowired
	UserRoleService userRoleService;

}*/
