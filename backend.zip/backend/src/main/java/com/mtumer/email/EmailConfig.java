package com.mtumer.email;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;

@Configuration
public class EmailConfig {
	
	@Bean
	public SimpleMailMessage emailTemplate() {
		SimpleMailMessage smm = new SimpleMailMessage();
		smm.setTo("1@gmnail.com");
		smm.setFrom("2@gmail.com");
		smm.setSubject("Test");
		smm.setText("This is test email");
		return smm;
	}
}
