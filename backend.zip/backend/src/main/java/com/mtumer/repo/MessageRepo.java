package com.mtumer.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mtumer.entity.Message;

public interface MessageRepo extends JpaRepository<Message, Long>{

}
